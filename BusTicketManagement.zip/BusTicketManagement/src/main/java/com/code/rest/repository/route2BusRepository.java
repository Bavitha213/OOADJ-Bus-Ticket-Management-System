package com.code.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

// import com.code.rest.entity.route1Bus;
import com.code.rest.entity.route2Bus;


public interface route2BusRepository extends JpaRepository<route2Bus, Long>{

}
