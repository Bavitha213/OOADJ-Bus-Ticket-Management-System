package com.code.rest.service.factory;

import java.util.List;

import com.code.rest.entity.Stop;

public interface StopFacade {
    public List<String> getAllStops();
}
