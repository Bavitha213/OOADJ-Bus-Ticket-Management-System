package com.code.rest.entity;

public interface Bus {
	void updateLocation(String Stop);

	Long getMid();
}
