package com.code.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.code.rest.entity.Route;



public interface RouteRepository extends JpaRepository<Route, Long>{


}
