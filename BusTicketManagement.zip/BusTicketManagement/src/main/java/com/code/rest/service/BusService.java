package com.code.rest.service;

import java.util.List;
import com.code.rest.entity.Bus;

public interface BusService {
    List<? extends Bus> getBus();
}
