package com.code.rest.service;


import com.code.rest.entity.Login;


public interface AdminService {
	public Boolean check(Login a);
	

}




