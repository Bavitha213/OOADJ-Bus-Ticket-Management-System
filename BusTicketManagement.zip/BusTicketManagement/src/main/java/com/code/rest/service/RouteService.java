package com.code.rest.service;

import java.util.List;

import com.code.rest.entity.Route;

public interface RouteService {
	public List<Route> getAll();
}
