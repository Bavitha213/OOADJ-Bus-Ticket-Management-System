package com.code.rest.entity;

public interface Stop {
	public void update();
	

}
