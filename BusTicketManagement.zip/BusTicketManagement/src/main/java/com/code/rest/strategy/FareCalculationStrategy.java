package com.code.rest.strategy;

public interface FareCalculationStrategy {
  double calculateFare(double distance);
}