package com.code.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.code.rest.entity.route1Bus;


public interface route1BusRepository extends JpaRepository<route1Bus, Long>{

}
